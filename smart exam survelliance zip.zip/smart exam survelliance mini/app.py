import os
import sqlite3
from datetime import datetime, timedelta
from io import BytesIO

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, send_from_directory

from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

import re
from werkzeug.security import generate_password_hash, check_password_hash

# Try to init DB helper if exists
from database import init_db
init_db()

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-local-key")

# EXAM CONFIG: 30 minutes (user requested)
EXAM_DURATION_SECONDS = 30 * 60  # 30 minutes
PASSING_MARKS = 55
MARKS_PER_QUESTION = {"correct": 5, "incorrect": -2}

# (Leave CORRECT_ANSWERS as-is or update to actual exam keys)
CORRECT_ANSWERS = {
    "q1": "a", "q2": "a", "q3": "a", "q4": "a", "q5": "a",
    "q6": "a", "q7": "a", "q8": "a", "q9": "a", "q10": "a",
    "q11": "a", "q12": "a", "q13": "a", "q14": "a", "q15": "a",
    "q16": "a", "q17": "a", "q18": "a", "q19": "a", "q20": "a",
    "q21": "a"
}

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "exam_surveillance.db")

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def calculate_score(answers: dict) -> int:
    total = 0
    for q, ans in answers.items():
        correct = CORRECT_ANSWERS.get(q)
        if correct is None:
            continue
        if ans == correct:
            total += MARKS_PER_QUESTION["correct"]
        else:
            total += MARKS_PER_QUESTION["incorrect"]
    return total

def clean_college_name(college_name: str) -> str:
    """Removes state in parentheses from college name, e.g., 'My College' -> 'My College'."""
    # Use regex to find and replace ' (Anything)' at the end of the string
    return re.sub(r'\s*\([^)]+\)$', '', college_name).strip()

# ---------------- Public routes ----------------

@app.route("/")
def index():
    if "student_roll" in session:
        return redirect(url_for("home"))
    return render_template("index.html")

@app.route("/register", methods=["POST"])
def register():
    # Expect JSON from front-end
    data = request.get_json() or {}
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    roll = data.get("roll_number", "").strip()
    college = data.get("college", "").strip()
    state = data.get("state", "").strip()
    password = data.get("password", "")
    confirm_password = data.get("confirm_password", "")

    if not (name and email and roll and college and state and password and confirm_password):
        return jsonify({"success": False, "message": "Please fill all required fields."})

    if not email.endswith("@gmail.com"):
        return jsonify({"success": False, "message": "Email must be a valid @gmail.com address."})

    if not (len(roll) == 5 and roll.isdigit()):
        return jsonify({"success": False, "message": "Roll number must be exactly 5 digits."})

    if len(password) < 6 or not (re.search("[a-z]", password) and re.search("[A-Z]", password) and re.search("[0-9]", password)):
        return jsonify({"success": False, "message": "Password must be at least 6 characters and contain an uppercase letter, a lowercase letter, and a number."})

    if password != confirm_password:
        return jsonify({"success": False, "message": "Passwords do not match."})

    hashed = generate_password_hash(password)

    conn = get_db_connection()
    try:
        conn.execute(
            "INSERT INTO students (name, email, roll_number, password, college, state) VALUES (?,?,?,?,?,?)",
            (name, email, roll, hashed, college, state)
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({"success": False, "message": "Email or Roll Number already exists."})
    conn.close()
    return jsonify({"success": True, "message": "Registration successful. Please login."})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not (email and password):
        return jsonify({"success": False, "message": "Provide email and password."})

    conn = get_db_connection()
    user = conn.execute("SELECT * FROM students WHERE email = ?", (email,)).fetchone()
    conn.close()
    if user and check_password_hash(user["password"], password):
        session["student_roll"] = user["roll_number"]
        session["student_name"] = user["name"]
        session["student_college"] = user["college"]
        return jsonify({"success": True, "redirect": url_for("home")})
    return jsonify({"success": False, "message": "Invalid credentials."})

@app.route("/logout")
def logout():
    was_examiner = session.pop("is_examiner", False)
    session.clear()
    if was_examiner:
        return redirect(url_for("examiner_page"))
    return redirect(url_for("index"))

# ---------------- Student pages ----------------

@app.route("/home")
def home():
    if "student_roll" not in session:
        return redirect(url_for("index"))
    return render_template("home.html",
                           student_name=session.get("student_name"),
                           student_roll=session.get("student_roll"))

@app.route("/exam")
def exam():
    if "student_roll" not in session:
        return redirect(url_for("index"))

    # prevent re-taking if already submitted
    conn = get_db_connection()
    res = conn.execute(
        "SELECT id FROM exam_results WHERE student_roll_number = ? ORDER BY submitted_at DESC LIMIT 1",
        (session["student_roll"],)
    ).fetchone()
    conn.close()
    if res:
        flash("You have already submitted the exam.", "info")
        return redirect(url_for("home"))

    # Provide human-readable duration
    hours = EXAM_DURATION_SECONDS // 3600
    minutes = (EXAM_DURATION_SECONDS % 3600) // 60
    duration_str = ""
    if hours:
        duration_str += f"{hours} hour{'s' if hours>1 else ''} "
    if minutes:
        duration_str += f"{minutes} minute{'s' if minutes>1 else ''}"
    duration_str = duration_str.strip() or f"{EXAM_DURATION_SECONDS} seconds"

    return render_template("exam.html", student=session, exam_duration=EXAM_DURATION_SECONDS, exam_duration_str=duration_str)

# ---------------- API logging & submission ----------------

@app.route("/log_activity", methods=["POST"])
def log_activity():
    if "student_roll" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    data = request.get_json() or {}
    behavior = data.get("behavior", "unknown")
    exam_part = data.get("exam_part")
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO activity_logs (student_roll_number, behavior, exam_part, timestamp) VALUES (?, ?, ?, ?)",
        (session.get("student_roll"), behavior, exam_part, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    )
    conn.commit()
    conn.close()
    return jsonify({"success": True})

@app.route("/submit_exam", methods=["POST"])
def submit_exam():
    if "student_roll" not in session:
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    data = request.get_json() or {}
    answers = data.get("answers", {})
    marks = calculate_score(answers)
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO exam_results (student_roll_number, marks, submitted_at) VALUES (?, ?, ?)",
        (session["student_roll"], marks, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
    )
    conn.commit()
    conn.close()
    # Clear session so student is logged out after submission
    session.clear()
    return jsonify({"success": True, "redirect": url_for("index")})

# ---------------- Examiner ----------------

@app.route("/examiner")
def examiner_page():
    return render_template("examiner_login.html")

@app.route("/examiner_login_action", methods=["POST"])
def examiner_login_action():
    password = request.form.get("password", "")
    EXAMINER_PASSWORD = os.environ.get("EXAMINER_PASSWORD", "examcyber369")
    if password == EXAMINER_PASSWORD:
        session["is_examiner"] = True
        return redirect(url_for("examiner_portal"))
    flash("Invalid password", "error")
    return redirect(url_for("examiner_page"))

@app.route("/examiner_portal")
def examiner_portal():
    if not session.get("is_examiner"):
        return redirect(url_for("examiner_page"))
    return render_template("examiner_portal.html")

@app.route("/dashboard")
def dashboard():
    if not session.get("is_examiner"):
        return redirect(url_for("examiner_page"))

    conn = get_db_connection()
    total_students = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    unique_suspicious = conn.execute("SELECT COUNT(DISTINCT student_roll_number) FROM activity_logs").fetchone()[0]
    total_questions = len(CORRECT_ANSWERS)
    total_marks = total_questions * MARKS_PER_QUESTION["correct"]

    students_data = conn.execute("""
        SELECT s.name, s.college, s.state, s.roll_number,
               er.marks
        FROM students s
        LEFT JOIN (
            SELECT student_roll_number, marks
            FROM exam_results
            WHERE id IN (
                SELECT id FROM exam_results ORDER BY submitted_at DESC
            )
        ) er ON er.student_roll_number = s.roll_number
        ORDER BY s.name
    """).fetchall()

    activity_counts = conn.execute("SELECT student_roll_number, COUNT(*) as cnt FROM activity_logs GROUP BY student_roll_number").fetchall()
    act_map = {r["student_roll_number"]: r["cnt"] for r in activity_counts}
    conn.close()

    students_list = []
    for s in students_data:
        students_list.append({
            "name": s["name"],
            "college": clean_college_name(s["college"]),
            "state": s["state"],
            "roll_number": s["roll_number"],
            "marks": s["marks"],
            "suspicious_count": act_map.get(s["roll_number"], 0)
        })

    return render_template("dashboard.html",
                           total_students=total_students,
                           suspicious_events=unique_suspicious,
                           students=students_list,
                           total_marks=total_marks,
                           correct_marks=MARKS_PER_QUESTION["correct"],
                           incorrect_marks=MARKS_PER_QUESTION["incorrect"],
                           passing_marks=PASSING_MARKS)

@app.route("/activity_logs_page")
def activity_logs_page():
    if not session.get("is_examiner"):
        return redirect(url_for("examiner_page"))

    conn = get_db_connection()
    logs = conn.execute("""
        SELECT al.student_roll_number, s.name, s.college, s.state, al.behavior, al.timestamp
        FROM activity_logs al
        JOIN students s ON s.roll_number = al.student_roll_number
        ORDER BY al.timestamp DESC
    """).fetchall()
    conn.close()

    grouped = {}
    for r in logs:
        roll = r["student_roll_number"]
        grouped.setdefault(roll, {"student_name": r["name"], "college": clean_college_name(r["college"]), "state": r["state"], "activities": {}, "last_activity_time": None})
        grouped[roll]["activities"][r["behavior"]] = grouped[roll]["activities"].get(r["behavior"], 0) + 1
        grouped[roll]["last_activity_time"] = r["timestamp"]

    logs_for_template = []
    for roll, info in grouped.items():
        logs_for_template.append({
            "student_roll_number": roll,
            "student_name": info["student_name"],
            "college": info["college"],
            "state": info["state"],
            "activities": info["activities"],
            "last_activity_time_ist": (datetime.strptime(info["last_activity_time"], "%Y-%m-%d %H:%M:%S") + timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %I:%M:%S %p") if info["last_activity_time"] else "N/A"
        })

    return render_template("activity_logs_page.html", logs=logs_for_template)

@app.route("/report_generator")
def report_generator():
    if not session.get("is_examiner"):
        return redirect(url_for("examiner_page"))
    return render_template("report_generator.html")

@app.route("/generate_and_send_report", methods=["POST"])
def generate_and_send_report():
    if not session.get("is_examiner"):
        return redirect(url_for("examiner_page"))

    report_type = request.form.get("report_type", "dashboard")
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"{report_type}report{timestamp}.pdf"

    conn = get_db_connection()
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    elements.append(Paragraph("Smart Exam Surveillance Report", styles["h1"]))
    elements.append(Spacer(1, 12))

    if report_type == "dashboard":
        total_students = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        total_suspicious = conn.execute("SELECT COUNT(DISTINCT student_roll_number) FROM activity_logs").fetchone()[0]
        elements.append(Paragraph(f"Total Registered Students: {total_students}", styles["Normal"]))
        elements.append(Paragraph(f"Total Suspicious Students: {total_suspicious}", styles["Normal"]))
        elements.append(Spacer(1, 12))

        rows = [["Name", "Roll No", "College", "State", "Marks", "Result", "Suspicious Acts"]]
        students = conn.execute("""
            SELECT s.name, s.roll_number, s.college, s.state, er.marks
            FROM students s
            LEFT JOIN exam_results er ON s.roll_number = er.student_roll_number
            ORDER BY s.name
        """).fetchall()
        activity_counts = {r["student_roll_number"]: r["cnt"] for r in conn.execute("SELECT student_roll_number, COUNT(*) cnt FROM activity_logs GROUP BY student_roll_number").fetchall()}
        for s in students:
            marks = s["marks"]
            result = "N/A"
            if marks is not None:
                if marks >= PASSING_MARKS:
                    result = "Pass"
                else:
                    result = "Fail"

            rows.append([
                Paragraph(s["name"], styles["Normal"]),
                s["roll_number"],
                Paragraph(clean_college_name(s["college"]), styles["Normal"]),
                s["state"],
                marks if marks is not None else "N/A",
                result,
                activity_counts.get(s["roll_number"], 0)
            ])

        table = Table(rows, colWidths=[80, 55, 100, 75, 45, 45, 80])
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0059b3")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("PADDING", (0, 0), (-1, -1), 8),
        ]))
        elements.append(table)

    elif report_type == "activity":
        rows = [["Name", "Roll No", "College", "State", Paragraph("Activities Summary", styles["Normal"]), "Last Activity (IST)"]]
        logs = conn.execute("""
            SELECT al.student_roll_number, s.name, s.college, s.state, al.behavior, al.timestamp
            FROM activity_logs al
            JOIN students s ON s.roll_number = al.student_roll_number
            ORDER BY al.timestamp DESC
        """).fetchall()

        by_student = {}
        for r in logs:
            roll = r["student_roll_number"]
            by_student.setdefault(roll, {"name": r["name"], "college": clean_college_name(r["college"]), "state": r["state"], "activities": {}, "last_time": None})
            by_student[roll]["activities"][r["behavior"]] = by_student[roll]["activities"].get(r["behavior"], 0) + 1
            by_student[roll]["last_time"] = r["timestamp"]

        for roll, info in by_student.items():
            summary = "<br/>".join([f"{b}: {c}" for b, c in info["activities"].items()])
            ist = (datetime.strptime(info["last_time"], "%Y-%m-%d %H:%M:%S") + timedelta(hours=5, minutes=30)).strftime("%Y-%m-%d %I:%M:%S %p") if info["last_time"] else "N/A"
            rows.append([Paragraph(info["name"], styles["Normal"]), roll, Paragraph(clean_college_name(info["college"]), styles["Normal"]), info["state"], Paragraph(summary, styles["Normal"]), Paragraph(ist, styles["Normal"])])
        
        table = Table(rows, colWidths=[80, 60, 110, 70, 110, 100])
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#d9534f")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("PADDING", (0, 0), (-1, -1), 8),
        ]))
        elements.append(table)

    conn.close()
    doc.build(elements)

    REPORTS_DIR = os.path.join(app.root_path, "static", "reports")
    os.makedirs(REPORTS_DIR, exist_ok=True)
    file_path = os.path.join(REPORTS_DIR, filename)

    with open(file_path, "wb") as f:
        f.write(buffer.getvalue())

    buffer.seek(0)
    return jsonify({"success": True, "filename": filename})


@app.route("/static/reports/<filename>")
def serve_report(filename):
    return send_from_directory(os.path.join(app.root_path, "static", "reports"), filename)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")