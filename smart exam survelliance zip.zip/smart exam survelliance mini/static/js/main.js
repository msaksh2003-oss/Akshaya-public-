// ======================================================
// LOGIN + REGISTER PAGE
// ======================================================
document.addEventListener("DOMContentLoaded", () => {

    const show = el => el.classList.remove("hidden");
    const hide = el => el.classList.add("hidden");

    const loginTab = document.getElementById("login-tab");
    const registerTab = document.getElementById("register-tab");
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");

    if (loginTab && registerTab) {
        loginTab.addEventListener("click", () => {
            loginTab.classList.add("active");
            registerTab.classList.remove("active");
            hide(registerForm);
            show(loginForm);
        });

        registerTab.addEventListener("click", () => {
            registerTab.classList.add("active");
            loginTab.classList.remove("active");
            hide(loginForm);
            show(registerForm);
        });
    }

    document.getElementById("show-register")?.addEventListener("click", e => {
        e.preventDefault();
        registerTab.click();
    });

    document.getElementById("show-login")?.addEventListener("click", e => {
        e.preventDefault();
        loginTab.click();
    });

    // LOGIN ----------------
    if (loginForm) {
        loginForm.addEventListener("submit", async e => {
            e.preventDefault();

            const payload = {
                email: document.getElementById("login-email").value.trim(),
                password: document.getElementById("login-password").value.trim(),
            };

            const res = await fetch("/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            const data = await res.json();
            document.getElementById("login-message").textContent = data.message;

            if (data.success) window.location.href = data.redirect;
        });
    }

    // REGISTRATION ----------------
    if (registerForm) {
        registerForm.addEventListener("submit", async e => {
            e.preventDefault();

            const payload = {
                name: document.getElementById("reg-name").value.trim(),
                email: document.getElementById("reg-email").value.trim(),
                roll_number: document.getElementById("reg-roll").value.trim(),
                college: document.getElementById("reg-college").value,
                state: document.getElementById("reg-state").value,
                password: document.getElementById("reg-password").value.trim(),
                confirm_password: document.getElementById("reg-confirm-password").value.trim(),
            };

            const res = await fetch("/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            const data = await res.json();
            document.getElementById("register-message").textContent = data.message;

            if (data.success) loginTab.click();
        });
    }

    // Password visibility toggles
    document.querySelectorAll('.toggle-password').forEach(toggle => {
        toggle.addEventListener('click', () => {
            const passwordInput = toggle.previousElementSibling;
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggle.classList.add('visible');
            } else {
                passwordInput.type = 'password';
                toggle.classList.remove('visible');
            }
        });
    });
});
    

// ======================================================
// START EXAM BUTTON (home.html)
// ======================================================
const startBtn = document.getElementById("start-exam-btn");
const rollInput = document.getElementById("roll-number-verify");

if (startBtn && rollInput) {
    startBtn.addEventListener("click", () => {
        const entered = rollInput.value.trim();
        const actual = document.body.getAttribute("data-roll");
        const errorEl = document.getElementById("roll-error");

        // Always hide error first
        errorEl.classList.add("hidden");

        if (!entered) {
            errorEl.textContent = "Please enter your Roll Number.";
            errorEl.classList.remove("hidden");
            return;
        }
        if (entered !== actual) {
            errorEl.textContent = "Entered Roll Number is Incorrect!";
            errorEl.classList.remove("hidden");
            return;
        }

        window.location.href = "/exam";
    });
}


// ======================================================
// EXAM PAGE SCRIPT
// ======================================================
document.addEventListener("DOMContentLoaded", () => {

    if (document.body.id !== "exam-page") return;
    let isSubmitting = false; // Flag to disable activity listeners on submit

    // ---------------- TIMER (30 minutes = 1800 sec) ----------------
    let duration = 1800;
    const timerEl = document.getElementById("timer");
    let examTimer = null;

    function formatTime(sec) {
        let h = Math.floor(sec / 3600);
        let m = Math.floor((sec % 3600) / 60);
        let s = sec % 60;

        return (
            String(h).padStart(2, "0") + ":" +
            String(m).padStart(2, "0") + ":" +
            String(s).padStart(2, "0")
        );
    }

    function updateTimer() {
        timerEl.textContent = formatTime(duration);

        if (duration <= 0) {
            submitExam();
            return;
        }

        duration--;
        examTimer = setTimeout(updateTimer, 1000);
    }

    updateTimer();   // start now


    // ---------------- INSTRUCTIONS POPUP ----------------
    document.getElementById("instructions-btn")?.addEventListener("click", () => {
        document.getElementById("instructions-modal").classList.remove("hidden");
    });
    document.getElementById("close-instructions")?.addEventListener("click", () => {
        document.getElementById("instructions-modal").classList.add("hidden");
    });


    // ---------------- CALCULATOR POPUP ----------------
    const calcResult = document.getElementById("calc-result");

    document.getElementById("calculator-btn")?.addEventListener("click", () => {
        document.getElementById("calculator-modal").classList.remove("hidden");
    });

    document.getElementById("close-calculator")?.addEventListener("click", () => {
        document.getElementById("calculator-modal").classList.add("hidden");
        calcResult.value = "";
    });

    document.querySelectorAll(".calc-keys button").forEach(btn => {
        btn.addEventListener("click", () => {
            let val = btn.textContent;
            if (val === "C") {
                calcResult.value = "";
            } else if (val === "=") {
                try { calcResult.value = eval(calcResult.value); }
                catch { calcResult.value = "Err"; }
            } else {
                calcResult.value += val;
            }
        });
    });


    // ---------------- SWITCH TO PART 2 ----------------
    document.getElementById("unlock-part2-btn")?.addEventListener("click", () => {
        document.getElementById("section-0").classList.add("hidden");
        document.getElementById("section-1").classList.remove("hidden");
        document.getElementById("part-2-tab").disabled = false;
    });


    // ---------------- SUSPICIOUS ACTIVITY ----------------
    function logActivity(type) {
        fetch("/log_activity", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ behavior: type })
        });
    }

    const pop = document.getElementById("suspicious-alert-popup");
    const popMsg = document.getElementById("suspicious-alert-message");

    function showSuspicious(msg) {
        popMsg.textContent = msg;
        pop.classList.remove("hidden");
        setTimeout(() => pop.classList.add("hidden"), 6000);   // 6 seconds
    }

    document.addEventListener("visibilitychange", () => {
        if (isSubmitting) return;
        // This event is best for detecting when the window is minimized or restored.
        logActivity("WINDOW BLUR");
        showSuspicious("Window Minimized!");
    });

    window.addEventListener("blur", () => {
        if (isSubmitting) return;
        // This event reliably detects when the user switches to another tab or window.
        logActivity("TAB SWITCH");
        showSuspicious("Tab Switching Detected!");
    });

    window.addEventListener("keyup", (e) => {
        if (isSubmitting) return;
        if (e.key === "PrintScreen") {
            logActivity("PRINT SCREEN");
            showSuspicious("Screenshot Attempt Detected!");
        }
    });


    // ---------------- SUBMIT EXAM ----------------
    const submitModal = document.getElementById("submit-popup");

    document.getElementById("btn-submit-exam")?.addEventListener("click", () => {
        submitModal.classList.remove("hidden");
    });

    document.getElementById("popup-no")?.addEventListener("click", () => {
        submitModal.classList.add("hidden");
    });

    document.getElementById("popup-yes")?.addEventListener("click", () => {
        submitModal.classList.add("hidden");
        submitExam();
    });


    function submitExam() {
        isSubmitting = true; // Disable all activity listeners
        clearTimeout(examTimer);

        const answers = {};
        document.querySelectorAll("input[type=radio]:checked").forEach(r => {
            answers[r.name] = r.value;
        });

        fetch("/submit_exam", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ answers })
        })
            .then(res => res.json())
            .then(data => {
                alert("Thank you for attending the exam.\nYou will now be logged out.");
                window.location.href = data.redirect;
            });
    }
});