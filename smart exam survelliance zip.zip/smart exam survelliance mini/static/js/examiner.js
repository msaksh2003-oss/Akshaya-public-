// ================================
//  EXAMINER PANEL JAVASCRIPT
// ================================

// Run only when DOM is ready
document.addEventListener("DOMContentLoaded", () => {

    console.log("Examiner Panel Loaded");

    // ============= DASHBOARD SEARCH BAR =============
    const searchInput = document.getElementById("search-student");

    if (searchInput) {
        searchInput.addEventListener("keyup", function () {
            let filter = searchInput.value.toLowerCase();
            let rows = document.querySelectorAll(".student-row");

            rows.forEach(row => {
                let name = row.querySelector(".col-name").textContent.toLowerCase();
                let roll = row.querySelector(".col-roll").textContent.toLowerCase();

                if (name.includes(filter) || roll.includes(filter)) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        });
    }

    // ============= REPORT GENERATOR =============
    const reportForm = document.getElementById("report-form");
    const popup = document.getElementById("confirmation-popup");
    const popupTitle = document.getElementById("popup-title");
    const popupMessage = document.getElementById("popup-message");
    const downloadLink = document.getElementById("download-link");
    const closeBtn = document.getElementById("close-popup-btn");
    const popupButtonContainer = document.getElementById("popup-buttons-container");

    if (reportForm) {
        reportForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            popup.classList.remove("hidden");
            popupTitle.textContent = "Processing...";
            popupMessage.textContent = "Your report is being generated. Please wait...";
            downloadLink.classList.add("hidden");

            let formData = new FormData(reportForm);

            let res = await fetch("/generate_and_send_report", {
                method: "POST",
                body: formData,
            });

            let data = await res.json();

            if (data.success) {
                popupTitle.textContent = "Report Ready!";
                popupMessage.textContent = "Click below to download your report.";
                downloadLink.href = `/static/reports/${data.filename}`;
                downloadLink.classList.remove("hidden");
                popupButtonContainer.classList.remove("hidden");
            } else {
                popupTitle.textContent = "Error";
                popupMessage.textContent = "Something went wrong.";
            }
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener("click", () => {
            popup.classList.add("hidden");
        });
    }

});