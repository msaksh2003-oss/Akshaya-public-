@echo off
REM This command tells the script to run from its own folder
cd /d "%~dp0"

REM Set a title for the command window
title Smart Exam Server

echo(
echo Starting your Smart Exam application...
echo If the window closes immediately, there is an error.

flask run --host=0.0.0.0

echo(
echo The application has stopped. You can close this window now.
pause
