from werkzeug.security import generate_password_hash
import getpass
import sys

def main():
    """Generates a secure password hash for the examiner."""
    print("--- Examiner Password Hash Generator ---")
    
    # Use getpass to securely read the password without showing it on screen
    try:
        password = getpass.getpass("Enter the new examiner password: ")
        password_confirm = getpass.getpass("Confirm the new examiner password: ")
    except (IOError, EOFError):
        print("\nCould not read password. Are you running this in a standard terminal?")
        sys.exit(1)

    if not password or password != password_confirm:
        print("\nError: Passwords do not match or were empty. Please try again.")
        return

    hashed_password = generate_password_hash(password, method='scrypt')
    print("\n--- SUCCESS! ---")
    print("Copy the following line and paste it into your .flaskenv file, replacing the old EXAMINER_PASSWORD_HASH line:\n")
    print(f"EXAMINER_PASSWORD_HASH={hashed_password}")

if __name__ == '__main__':
    main()